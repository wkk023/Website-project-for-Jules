import { parse } from "csv-parse/sync";
import * as XLSX from "xlsx";

export interface BulkImportRecord {
  buildingId: string;
  address: string;
  location: string;
  buildingType: string;
  riskCategory: string;
}

export interface BulkImportResult {
  success: boolean;
  records?: BulkImportRecord[];
  errors?: string[];
  totalRecords: number;
  validRecords: number;
}

/**
 * Parse CSV content and extract inspection records
 */
export function parseCSV(content: string): BulkImportRecord[] {
  const records = parse(content, {
    columns: true,
    skip_empty_lines: true,
  });

  return records.map((record: any) => {
    // Normalize header names (handle variations in casing and spacing)
    const normalizedRecord: any = {};
    for (const [key, value] of Object.entries(record)) {
      const normalizedKey = (key as string).toLowerCase().trim();
      normalizedRecord[normalizedKey] = value;
    }

    return {
      buildingId: normalizedRecord["building id"] || normalizedRecord["building_id"] || normalizedRecord["buildingid"] || "",
      address: normalizedRecord["address"] || "",
      location: normalizedRecord["location"] || "",
      buildingType: normalizedRecord["building type"] || normalizedRecord["building_type"] || "",
      riskCategory: normalizedRecord["risk category"] || normalizedRecord["risk_category"] || "",
    };
  });
}

/**
 * Parse Excel file content and extract inspection records
 */
export function parseExcel(buffer: Buffer): BulkImportRecord[] {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const worksheet = workbook.Sheets[workbook.SheetNames[0]];
  const records = XLSX.utils.sheet_to_json(worksheet);

  return records.map((record: any) => {
    // Normalize header names (handle variations in casing and spacing)
    const normalizedRecord: any = {};
    for (const [key, value] of Object.entries(record)) {
      const normalizedKey = (key as string).toLowerCase().trim();
      normalizedRecord[normalizedKey] = value;
    }

    return {
      buildingId: normalizedRecord["building id"] || normalizedRecord["building_id"] || normalizedRecord["buildingid"] || "",
      address: normalizedRecord["address"] || "",
      location: normalizedRecord["location"] || "",
      buildingType: normalizedRecord["building type"] || normalizedRecord["building_type"] || "",
      riskCategory: normalizedRecord["risk category"] || normalizedRecord["risk_category"] || "",
    };
  });
}

/**
 * Validate a single record
 */
export function validateRecord(record: BulkImportRecord): string | null {
  if (!record.buildingId || record.buildingId.trim() === "") {
    return "Missing Building ID";
  }
  if (!record.address || record.address.trim() === "") {
    return "Missing Address";
  }
  if (!record.location || record.location.trim() === "") {
    return "Missing Location";
  }
  if (!record.buildingType || record.buildingType.trim() === "") {
    return "Missing Building Type";
  }
  if (!record.riskCategory || record.riskCategory.trim() === "") {
    return "Missing Risk Category";
  }

  // Validate risk category
  const validRiskCategories = ["A*", "A", "B", "C", "D", "E"];
  if (!validRiskCategories.includes(record.riskCategory)) {
    return `Invalid Risk Category: ${record.riskCategory}. Must be one of: ${validRiskCategories.join(", ")}`;
  }

  return null;
}

/**
 * Process and validate bulk import records
 */
export function processBulkImport(records: BulkImportRecord[]): BulkImportResult {
  const errors: string[] = [];
  const validRecords: BulkImportRecord[] = [];

  records.forEach((record, index) => {
    const error = validateRecord(record);
    if (error) {
      errors.push(`Row ${index + 2}: ${error}`);
    } else {
      validRecords.push(record);
    }
  });

  return {
    success: errors.length === 0,
    records: errors.length === 0 ? validRecords : undefined,
    errors: errors.length > 0 ? errors : undefined,
    totalRecords: records.length,
    validRecords: validRecords.length,
  };
}
